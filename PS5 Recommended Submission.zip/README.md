# PS5 competition submission

Extract this ZIP and place the labeled test files next to `Evaluate Test Sets.ipynb`. Name them `fraud_test.csv` and `activity_test.csv`, or set their names in the first code cell. Prepare the evaluator environment before competition day, then open the notebook and choose **Run All**. The notebook writes `results/fraud_predictions.csv`, `results/activity_predictions.csv`, and `results/metrics.txt`.

## Python environments

The supplied course environment is included verbatim as `environment_idai610.yml`. It pins Python 3.10.10 and scikit-learn 1.5.1. You can open the notebook from that environment and launch evaluation using a separate Python interpreter. The exact frozen pickles were verified with Python 3.12 and scikit-learn 1.9.1. Keep the course pins and install the evaluator pins in a separate environment.

**Conda.** Run these commands from the extracted folder on a machine with Conda. Paste the printed absolute Python path into `EVALUATOR_PYTHON` in the notebook, using `Path(r"...")`.

```sh
conda env create -f environment_evaluator.yml
conda run -n idai610-ps5-evaluator python -c "import sys; print(sys.executable)"
```

**Already have Python 3.12.** Create an evaluator virtual environment named `.eval` in the extracted folder. The notebook detects it automatically.

```powershell
# Windows, using the path to your Python 3.12 interpreter
& "C:\path\to\python.exe" -m venv .eval
.\.eval\Scripts\python.exe -m pip install -r requirements.txt
```

```sh
# Linux or macOS
python3.12 -m venv .eval
.eval/bin/python -m pip install -r requirements.txt
```

The notebooks perform version checks and launch the evaluator. Installation is a separate one-time step. It requires package index access or compatible wheels in a local cache. The ZIP exports pinned package lists, including the evaluator dependencies found on the build machine. For an offline grader, provision the evaluator environment on the target platform before competition day. CPU evaluation is supported.

## Command-line evaluation

With the evaluator environment active, run this from the extracted folder.

```sh
python evaluate.py --fraud-test fraud_test.csv --activity-test activity_test.csv --output-dir results
```

- **Fraud.** Supply the original headered CSV with `is_fraud` as its last column. Pass the whole file in one invocation so earlier transactions in that file can inform later ones. The evaluator prints accuracy, macro-F1, fraud F1, and ROC AUC.
- **Activity.** Supply the original headerless CSV with 328 numeric sensor columns followed by the gold activity name. The evaluator prints accuracy and macro-F1.
- **Output.** Each prediction CSV preserves the input order and field values, with predictions replacing the last column. A successful rerun replaces the previous prediction files in the selected output folder.

## Frozen models

The fraud model is the 75% forest and 25% XGBoost blend with threshold 0.66036648. The activity model is the 65% class-frequency-adjusted ensemble and 35% class-balanced RBF SVM with C=4. `Frozen Model Summary.ipynb` shows the recorded development scores and checks that both model files match `freeze_manifest.json`. Use this trusted local bundle when loading the pickles.
