# Frozen model metrics

These scores come from held-out development predictions. The official competition test sets were unavailable when the models were frozen.

| Task | Accuracy | Macro-F1 | Fraud F1 | ROC AUC |
|---|---:|---:|---:|---:|
| Credit card fraud | 99.97178% | 0.983321 | 0.966783 | 0.995196 |
| Human activity recognition | 81.4496% | 0.724994 | — | — |

- **Fraud.** Across 269,318 transactions in three chronological validation periods, the selected model caught 1,106 frauds, missed 62, and raised 14 false alerts. Each period began with empty transaction history, and its alert threshold was selected using earlier periods. The frozen predictor blends 75% random forest and 25% XGBoost.
- **Activity.** Scores come from 2,442 readings in the original four grouped folds. Identical sensor readings stayed in the same fold. The selected 65% activity ensemble and 35% class-balanced RBF SVM blend also improved macro-F1 on both additional grouped splits.

Run **Evaluate Test Sets.ipynb** to generate competition predictions and save the test metrics to `results/metrics.txt`.
